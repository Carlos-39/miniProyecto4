
package supermercadounivalle;

import controlador.SuperMercadoController;

/**
 * MiniProyecto 4 - SuperMercado Univalle
 * @author Carlos Daniel Corrales Arango <2122878>
 * @author Juleipssy Daianne Cely Archila <2122036>
 * @author Yenni Margot Rivas <2182527>
 * @profesor Luis Yovany Romo Portilla
 * Clase principal
 */
public class Principal {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        SuperMercadoController superMercadoController = new SuperMercadoController();
        superMercadoController.attachShutDownHook();
    }
    
}
