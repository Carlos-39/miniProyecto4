
package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * MiniProyecto 4 - SuperMercado Univalle
 * @author Carlos Daniel Corrales Arango <2122878>
 * @author Juleipssy Daianne Cely Archila <2122036>
 * @author Yenni Margot Rivas <2182527>
 * @profesor Luis Yovany Romo Portilla
 * Clase que representa a una factura de venta
 */
public class Factura implements Serializable{
    private String nombre;
    private String id;
    private final ArrayList<HashMap<String,String>> carrito;
    private int total;

    public Factura(String nombre, String id, ArrayList<HashMap<String, String>> carrito, int total) {
        this.nombre = nombre;
        this.id = id;
        this.carrito = carrito;
        this.total = total;
    }

    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public ArrayList<HashMap<String, String>> getCarrito() {
        return carrito;
    }

    public int getTotal() {
        return total;
    }
    
}
